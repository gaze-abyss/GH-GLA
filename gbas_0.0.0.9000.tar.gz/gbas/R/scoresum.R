#' scoresum
#'
#' @param z
#'
#' @return matrix
#' @export
#'
#' @examples
#' scoresum(z)
scoresum = function(z){
  scoresum = sum(as.numeric(z))
}
